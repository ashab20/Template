jQuery.exists = function (selector) { // функция проверки существования селектора
    return ($(selector).length > 0);
};

$(document).ready(function () {


});